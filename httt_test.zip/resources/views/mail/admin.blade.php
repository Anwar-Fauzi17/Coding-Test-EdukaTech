<!DOCTYPE html>
<html lang="en-US">
    <head>
        <meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
        <title>training</title>
        <meta name="description" content="training." />
        <style type="text/css">
            a:hover {
                text-decoration: underline !important;
            }
        </style>
    </head>

    <body
        marginheight="0"
        topmargin="0"
        marginwidth="0"
        style="margin: 0px; background-color: #f2f3f8"
        leftmargin="0"
    >
        <table
            cellspacing="0"
            border="0"
            cellpadding="0"
            width="100%"
            bgcolor="#f2f3f8"
            style="
                @import url(https://fonts.googleapis.com/css?family=Rubik:300,400,500,700|Open+Sans:300,400,600,700);
                font-family: 'Open Sans', sans-serif;
            "
        >
            <tr>
                <td>
                    <table
                        style="
                            background-color: #f2f3f8;
                            max-width: 670px;
                            margin: 0 auto;
                        "
                        width="100%"
                        border="0"
                        align="center"
                        cellpadding="0"
                        cellspacing="0"
                    >
                        <tr>
                            <td style="height: 80px">&nbsp;</td>
                        </tr>
                        <tr>
                            <td style="text-align: center">
                                <h1
                                    style="
                                        color: #6a3aaf;
                                        font-weight: 1500;
                                        margin: 0;
                                        font-size: 50px;
                                        font-family: 'Rubik', sans-serif;
                                    "
                                >
                                    Training.id
                                </h1>
                            </td>
                        </tr>
                        <tr>
                            <td style="height: 20px">&nbsp;</td>
                        </tr>
                        <tr>
                            <td>
                                <table
                                    width="95%"
                                    border="0"
                                    align="center"
                                    cellpadding="0"
                                    cellspacing="0"
                                    style="
                                        max-width: 670px;
                                        background: #fff;
                                        border-radius: 10px;
                                        text-align: center;
                                        -webkit-box-shadow: 0 6px 18px 0
                                            rgba(0, 0, 0, 0.06);
                                        -moz-box-shadow: 0 6px 18px 0
                                            rgba(0, 0, 0, 0.06);
                                        box-shadow: 0 6px 18px 0 #750ba1;
                                    "
                                >
                                    <tr>
                                        <td style="height: 40px">&nbsp;</td>
                                    </tr>
                                    <tr>
                                        <td style="padding: 0 35px">
                                            <h1
                                                style="
                                                    color: #1e1e2d;
                                                    font-weight: 500;
                                                    margin: 0;
                                                    font-size: 15px;
                                                    font-family: 'Rubik',
                                                        sans-serif;
                                                "
                                            >
                                                Hai {{ $data['name'] }} Anda
                                                Telah Berhasil Terdaftar Sebagai
                                            </h1>
                                            <br />
                                            <img
                                                style="
                                                    max-width: 353px;
                                                    height: 353px;
                                                    max-height: 300px;
                                                    width: 100%;
                                                "
                                                src="https://assets.webiconspng.com/uploads/2016/12/Verified-Modern-Icon.png"
                                                title="logo"
                                                alt="logo"
                                            />
                                            <p
                                                style="
                                                    color: #484d50;
                                                    font-size: 30px;
                                                    line-height: 24px;
                                                    margin: 0;
                                                    margin-bottom: 20px;
                                                    font-family: 'Rubik',
                                                        sans-serif;
                                                "
                                            >
                                                Admin Di Training.id
                                            </p>
                                            <hr style="color: #a8b3b9" />
                                            <p
                                                style="
                                                    color: #455056;
                                                    font-size: 10px;
                                                    line-height: 24px;
                                                    margin: 0;
                                                "
                                            >
                                                Terimakasih Atas Pendaftaran Admin 
                                            </p>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td style="height: 40px">&nbsp;</td>
                                    </tr>
                                </table>
                            </td>
                        </tr>

                        <tr>
                            <td style="height: 20px">&nbsp;</td>
                        </tr>
                        <tr>
                            <td style="text-align: center">
                                <p
                                    style="
                                        font-size: 12px;
                                        color: #b0adc5;
                                        line-height: 18px;
                                        margin: 0 0 0;
                                    "
                                >
                                    &copy;
                                    <strong>
                                        2022 training . All rights
                                        reserved</strong
                                    >
                                </p>
                            </td>
                        </tr>
                        <tr>
                            <td style="height: 80px">&nbsp;</td>
                        </tr>
                    </table>
                </td>
            </tr>
        </table>
        <!--/100% body table-->
    </body>
</html>
