 <?php $__env->startSection('content'); ?>

<div class="container pt-5">
    <div class="row d-flex justify-content-center align-items-center">
        <div class="col-lg-12">
            <div class="card" style="border-radius: 15px">
                <div class="card-body text-center">
                    <?php if(empty($user->profil)): ?>
                    <div class="mt-3 mb-4 text-center">
                        <div class="card profil">
                                 <h4 class="mb-2"><?php echo e(Str::limit($user->name,1)); ?></h4>
                        </div>
                    </div>
                    <?php else: ?>
                    <div class="mt-3 mb-4 text-center">
                        <div
                            class="rounded-circle img-fluid shadow-sm"
                            style=" width: 100px; height: 100px; margin:0 auto;  background-position: center;
                                background-repeat: no-repeat;
                                background-size: cover;
                                position: relative; background-image:url('<?php echo e(asset('/imgprofil/'.$user->profil)); ?>')"
                        ></div>
                    </div>
                    <?php endif; ?>
                    <h4 class="mb-2"><?php echo e($user->name); ?></h4>
                    <p class="text-muted mb-4 text-center">
                        Email <span class="mx-2">|</span> <?php echo e($user->email); ?>

                    </p>
                    <p class="text-muted mb-4 text-center">
                        Username <span class="mx-2">|</span> <?php echo e($user->username); ?>

                    </p>
                    
                    <a
                        href="<?php echo e('/logout'); ?>"
                        class="btn btn-rounded btn-lg mb-3"
                        > Logout</a
                    >
                
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.landing', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\httt_test\resources\views/admin/profil.blade.php ENDPATH**/ ?>