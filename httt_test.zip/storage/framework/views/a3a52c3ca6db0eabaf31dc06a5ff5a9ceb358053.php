

<?php $__env->startSection('content'); ?>
<style>
.owl-carousel .owl-stage {
    margin:0 auto;
}
</style>
<div class="container pt-5  mx-auto">         
    <div class="row d-flex justify-content-center pt-2 ">

        <div class="col-lg-10 col-md-12 col-sm-12 pt-5">
           <div class="card  bgcard">
               <h1>Hi <?php echo e($user->name); ?></h1>
               <p><?php echo e(Carbon\Carbon::now()->isoFormat('dddd, D MMMM Y')); ?></p>
               
           </div>
        </div>

        <div class="col-lg-5 col-md-5 col-sm-6 col-6 pt-5">
           <div class="card dash">
              <label class="text-center px-3 pt-3">Total Pendaftar Training</label> 
                <div class=" mb-3 text-center mt-2"><b> <h1 class="text-center " style=" font-size: 2.5em;"><?php echo e($per); ?></h1></b></div>
                <a href="<?php echo e(url('/user')); ?>" class="btn "> Cek Data Pendaftar</a>
           </div>
        </div>

        <div class="col-lg-5 col-md-5 col-sm-6 col-6 pt-5">
           <div class="card dash">
               <label class="text-center px-3 pt-3">Total Data Training</label> 
               <div class=" mb-3 text-center mt-2"><b> <h1 class="text-center " style=" font-size: 2.5em;"><?php echo e($pel); ?></h1></b></div>
                <a href="<?php echo e(url('/pelatihan')); ?>" class="btn "> Cek Data Pendaftar</a>
           </div>
        </div>
        <label class="text-center px-3 pt-3"><h3>Peminat Pelatihan</h3></label> 
        <div class="owl-carousel pelatihan owl-theme">
             <?php $__currentLoopData = $all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $an): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <div class="card pr">
               <p><?php echo e($an->nama); ?></p>
               <p><?php echo e($an->count); ?></p>
            </div>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              
          </div>

    </div>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.landing', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\httt_test\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>