

<?php $__env->startSection('content'); ?>

<div class="container-fluid pt-5  mx-auto ">
    <div class="row d-flex justify-content-center">
        <div class="col-xl-6 col-lg-8 col-md-9 col-11 text-center">
       
        <div class="card pr">
         
                <?php if(Session::has('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(Session::get('success')); ?>

                </div>
            <?php endif; ?>
            <?php if(Session::has('error')): ?>
                <div class="alert alert-danger">
                <?php echo e(Session::get('error')); ?>

                </div>
            <?php endif; ?> 
            
            <div class="row justify-content-between text-left">
                    <div class="form-group col-sm-12 flex-column d-flex"><h2><b>Tambah Data Training</b></h2></div>
                     
                      
                </div>
            <form class="form-horizontal" action="<?php echo e(url('/simpanpelatihan')); ?>" method="POST" >

                 <?php echo csrf_field(); ?>
                 
                <div class="row justify-content-between text-center">
                    <div class="form-group col-sm-12 flex-column d-flex pt-3 pb-3"> Masukan Nama Training <input type="text" id="nama" name="nama" placeholder="Masukan Nama Pelatihan" required > </div>
                    
                </div>

                <div class="row justify-content-end">
                    <div class="form-group col-sm-12 pt-3 "> <button type="submit" class="btn"><b>Simpan</b></button> </div>
                </div>
            </form>
            
        </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.landing', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\httt_test\resources\views/admin/tambahpelatihan.blade.php ENDPATH**/ ?>